# [discord.gg/vsc](https://discord.gg/vsc) sunucusuna aittir. İzinsiz Paylaşılması Yasaktır.
# oktaydev